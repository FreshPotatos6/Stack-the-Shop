import pygame
import random
import asyncio
import os

# --- CONFIGURATION ---
SCREEN_WIDTH, SCREEN_HEIGHT = 450, 750 
GRID_SIZE = 30
COLUMNS, ROWS = 10, 20
BLACK = (15, 15, 18)
WHITE = (240, 240, 240)
GRAY = (40, 40, 40)

PART_DATA = {
    'Spark Plug': {'color': (255, 50, 50), 'img': 'sparkplug.png', 'desc': 'Ignites fuel/air mix.'},
    'Ignition Coil': {'color': (255, 165, 0), 'img': 'coil.png', 'desc': 'Transforms battery voltage.'},
    'Alternator': {'color': (255, 255, 0), 'img': 'alternator.png', 'desc': 'Charges electrical system.'},
    'VVT Solenoid': {'color': (160, 32, 240), 'img': 'vvt.png', 'desc': 'Controls valve timing.'},
    'O2 Sensor': {'color': (50, 255, 50), 'img': 'o2.png', 'desc': 'Measures exhaust oxygen.'}
}

SHAPES = {
    'Spark Plug': [(0, 1), (1, 1), (2, 1), (3, 1)],    
    'Ignition Coil': [(0, 0), (0, 1), (0, 2), (1, 2)], 
    'Alternator': [(0, 0), (1, 0), (0, 1), (1, 1)],    
    'VVT Solenoid': [(0, 0), (0, 1), (1, 1), (2, 0)],  
    'O2 Sensor': [(0, 0), (0, 1), (1, 1), (1, 2)]      
}

class Piece:
    def __init__(self, name):
        self.name = name
        self.shape = list(SHAPES[name])
        self.original_shape = list(SHAPES[name]) # Used for texture mapping
        self.color = PART_DATA[name]['color']
        self.desc = PART_DATA[name]['desc']
        self.x = COLUMNS // 2 - 2
        self.y = 0

class AutomotiveTetris:
    def __init__(self):
        pygame.init()
        self.screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
        self.clock = pygame.time.Clock()
        
        # --- INTELLIGENT ASSET LOADING ---
        self.images = {}
        base_dir = os.path.dirname(os.path.abspath(__file__))
        
        for part, data in PART_DATA.items():
            img_path = os.path.join(base_dir, "assets", data['img'])
            try:
                loaded_img = pygame.image.load(img_path).convert_alpha()
                
                # Calculate the "bounding box" of the original shape
                shape_coords = SHAPES[part]
                max_w = max(p[0] for p in shape_coords) + 1
                max_h = max(p[1] for p in shape_coords) + 1
                
                # Scale image to the TOTAL footprint (e.g., 90x60px for O2 sensor)
                self.images[part] = pygame.transform.scale(loaded_img, (max_w * GRID_SIZE, max_h * GRID_SIZE))
                print(f"LOADED: {part} at {max_w*GRID_SIZE}x{max_h*GRID_SIZE}px")
            except Exception as e:
                print(f"SKIPPED IMAGE: {part}. Using colors. Error: {e}")
                self.images[part] = None

        self.grid = [[None for _ in range(COLUMNS)] for _ in range(ROWS)]
        self.current_piece = Piece(random.choice(list(SHAPES.keys())))
        self.next_piece = Piece(random.choice(list(SHAPES.keys())))
        self.score = 0
        self.level = 1
        self.lines_cleared = 0
        self.game_over = False

        self.keys_held = {pygame.K_LEFT: False, pygame.K_RIGHT: False, pygame.K_DOWN: False}
        self.move_timer = 0
        self.move_delay = 70 
        self.initial_delay = 180

        # Mobile Buttons
        self.btn_l = pygame.Rect(10, 620, 100, 50); self.btn_r = pygame.Rect(120, 620, 100, 50)
        self.btn_rot = pygame.Rect(230, 620, 100, 50); self.btn_flip = pygame.Rect(340, 620, 100, 50)
        self.btn_drop = pygame.Rect(10, 680, 430, 50) 

    def check_collision(self, dx, dy, shape=None):
        shape = shape or self.current_piece.shape
        for px, py in shape:
            nx, ny = self.current_piece.x + px + dx, self.current_piece.y + py + dy
            if nx < 0 or nx >= COLUMNS or ny >= ROWS: return True
            if ny >= 0 and self.grid[ny][nx]: return True
        return False

    def try_rotate_with_kick(self, flip=False):
        if flip:
            new_shape = [(-x, y) for x, y in self.current_piece.shape]
        else:
            new_shape = [(y, -x) for x, y in self.current_piece.shape]
            
        for kick in [0, 1, -1, 2, -2]:
            if not self.check_collision(kick, 0, new_shape):
                self.current_piece.x += kick
                self.current_piece.shape = new_shape
                return True
        return False

    def freeze_piece(self):
        # NOTE: When frozen, we store the COLOR because the sliced texture 
        # mapping is difficult to maintain once rows start shifting/disappearing.
        for px, py in self.current_piece.shape:
            self.grid[self.current_piece.y + py][self.current_piece.x + px] = self.current_piece.name
        self.clear_lines()
        self.current_piece = self.next_piece
        self.next_piece = Piece(random.choice(list(SHAPES.keys())))
        if self.check_collision(0, 0): self.game_over = True

    def clear_lines(self):
        lines = [i for i, row in enumerate(self.grid) if all(row)]
        if lines:
            bonuses = {1: 100, 2: 300, 3: 500, 4: 800}
            self.score += bonuses.get(len(lines), 100) * self.level
            self.lines_cleared += len(lines)
            self.level = (self.lines_cleared // 10) + 1
            for i in lines:
                del self.grid[i]
                self.grid.insert(0, [None for _ in range(COLUMNS)])

    def draw(self):
        self.screen.fill(BLACK)
        pygame.draw.rect(self.screen, GRAY, (0, 0, COLUMNS * GRID_SIZE, ROWS * GRID_SIZE), 1)

        # 1. Draw Static Grid (Frozen pieces show as solid color/standard block)
        for y, row in enumerate(self.grid):
            for x, part_name in enumerate(row):
                if part_name:
                    pygame.draw.rect(self.screen, PART_DATA[part_name]['color'], (x*GRID_SIZE, y*GRID_SIZE, GRID_SIZE-1, GRID_SIZE-1))
        
        # 2. Draw Active Piece (Sliced Intelligence)
        # We use the 'original_shape' to determine which slice of the image to show
        img = self.images.get(self.current_piece.name)
        for i in range(len(self.current_piece.shape)):
            px, py = self.current_piece.shape[i]
            orig_px, orig_py = self.current_piece.original_shape[i] # Original texture coord
            
            x_pos, y_pos = (self.current_piece.x + px)*GRID_SIZE, (self.current_piece.y + py)*GRID_SIZE
            
            if img:
                # Calculate the 30x30 slice from the full part image
                crop_rect = pygame.Rect(orig_px * GRID_SIZE, orig_py * GRID_SIZE, GRID_SIZE, GRID_SIZE)
                self.screen.blit(img, (x_pos, y_pos), crop_rect)
            else:
                pygame.draw.rect(self.screen, self.current_piece.color, (x_pos, y_pos, GRID_SIZE-1, GRID_SIZE-1))

        # UI Drawing (Restored)
        ui_x = 315
        f_m = pygame.font.SysFont('Arial', 18, bold=True); f_s = pygame.font.SysFont('Arial', 14)
        self.screen.blit(f_m.render(f"LVL: {self.level}", True, WHITE), (ui_x, 20))
        self.screen.blit(f_m.render(f"SCORE: {self.score}", True, WHITE), (ui_x, 50))
        self.screen.blit(f_m.render("NEXT:", True, WHITE), (ui_x, 90))
        for px, py in self.next_piece.shape:
            pygame.draw.rect(self.screen, self.next_piece.color, (ui_x + px*15, 120 + py*15, 12, 12))
        self.screen.blit(f_m.render("PART INFO:", True, WHITE), (ui_x, 190))
        self.screen.blit(f_s.render(self.current_piece.name, True, self.current_piece.color), (ui_x, 215))

        # Mobile Buttons
        pygame.draw.rect(self.screen, (60, 60, 60), self.btn_l); pygame.draw.rect(self.screen, (60, 60, 60), self.btn_r)
        pygame.draw.rect(self.screen, (0, 80, 0), self.btn_rot); pygame.draw.rect(self.screen, (0, 0, 80), self.btn_flip)
        pygame.draw.rect(self.screen, (80, 0, 0), self.btn_drop)
        pygame.display.flip()

    async def run(self):
        fall_time = 0
        while not self.game_over:
            dt = self.clock.tick(60)
            fall_time += dt
            self.move_timer += dt

            base_speed = max(100, 500 - (self.level - 1) * 50)
            fall_speed = base_speed / 10 if self.keys_held[pygame.K_DOWN] else base_speed

            for event in pygame.event.get():
                if event.type == pygame.QUIT: return
                if event.type == pygame.MOUSEBUTTONDOWN:
                    pos = event.pos
                    if self.btn_l.collidepoint(pos): 
                        self.keys_held[pygame.K_LEFT] = True
                        if not self.check_collision(-1, 0): self.current_piece.x -= 1
                        self.move_timer = -self.initial_delay
                    if self.btn_r.collidepoint(pos): 
                        self.keys_held[pygame.K_RIGHT] = True
                        if not self.check_collision(1, 0): self.current_piece.x += 1
                        self.move_timer = -self.initial_delay
                    if self.btn_rot.collidepoint(pos): self.try_rotate_with_kick(False)
                    if self.btn_flip.collidepoint(pos): self.try_rotate_with_kick(True)
                    if self.btn_drop.collidepoint(pos):
                        while not self.check_collision(0, 1): self.current_piece.y += 1
                        self.freeze_piece()
                if event.type == pygame.MOUSEBUTTONUP:
                    self.keys_held[pygame.K_LEFT] = False; self.keys_held[pygame.K_RIGHT] = False

                if event.type == pygame.KEYDOWN:
                    if event.key in self.keys_held: 
                        self.keys_held[event.key] = True
                        if event.key == pygame.K_LEFT and not self.check_collision(-1, 0): self.current_piece.x -= 1
                        if event.key == pygame.K_RIGHT and not self.check_collision(1, 0): self.current_piece.x += 1
                        self.move_timer = -self.initial_delay
                    if event.key == pygame.K_SPACE: self.try_rotate_with_kick(False)
                    if event.key == pygame.K_UP: self.try_rotate_with_kick(True)
                    if event.key == pygame.K_RETURN:
                        while not self.check_collision(0, 1): self.current_piece.y += 1
                        self.freeze_piece()
                if event.type == pygame.KEYUP:
                    if event.key in self.keys_held: self.keys_held[event.key] = False

            if self.move_timer > self.move_delay:
                if self.keys_held[pygame.K_LEFT] and not self.check_collision(-1, 0): self.current_piece.x -= 1
                if self.keys_held[pygame.K_RIGHT] and not self.check_collision(1, 0): self.current_piece.x += 1
                self.move_timer = 0

            if fall_time > fall_speed:
                if not self.check_collision(0, 1): self.current_piece.y += 1
                else: self.freeze_piece()
                fall_time = 0
            self.draw()
            await asyncio.sleep(0)

if __name__ == "__main__":
    asyncio.run(AutomotiveTetris().run())