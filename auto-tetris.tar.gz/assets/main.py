import pygame
import random
import asyncio
import os
import sys

# --- CONFIGURATION ---
SCREEN_WIDTH, SCREEN_HEIGHT = 450, 750 
GRID_SIZE = 30
COLUMNS, ROWS = 10, 20
BLACK = (15, 15, 18)
WHITE = (240, 240, 240)
GRAY = (40, 40, 40)
IS_MOBILE = sys.platform == "emscripten" 

PART_DATA = {
    'Spark Plug': {'color': (255, 50, 50), 'img': 'sparkplug.png', 'desc': 'Ignites fuel/air mix.'},
    'Ignition Coil': {'color': (255, 165, 0), 'img': 'coil.png', 'desc': 'Transforms battery voltage.'},
    'Alternator': {'color': (255, 255, 0), 'img': 'alternator.png', 'desc': 'Charges electrical system.'},
    'VVT Solenoid': {'color': (160, 32, 240), 'img': 'vvt.png', 'desc': 'Controls valve timing.'},
    'O2 Sensor': {'color': (50, 255, 50), 'img': 'o2.png', 'desc': 'Measures exhaust oxygen.'}
}

SHAPES = {
    'Spark Plug': [(0, 0), (1, 0), (2, 0), (3, 0)],    
    'Ignition Coil': [(0, 0), (0, 1), (0, 2), (1, 2)], 
    'Alternator': [(0, 0), (1, 0), (0, 1), (1, 1)],    
    'VVT Solenoid': [(0, 1), (1, 1), (2, 1), (1, 0)],  
    'O2 Sensor': [(0, 1), (1, 0), (1, 1), (2, 0)]      
}

class Piece:
    def __init__(self, name):
        self.name = name
        self.shape = list(SHAPES[name])
        self.color = PART_DATA[name]['color']
        self.desc = PART_DATA[name]['desc']
        self.x = COLUMNS // 2 - 1
        self.y = 0
        self.is_flipped = False
        self.rotation = 0

class AutomotiveTetris:
    def __init__(self):
        pygame.init()
        self.screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
        self.clock = pygame.time.Clock()
        
        self.images = {}
        base_dir = os.path.dirname(os.path.abspath(__file__))
        for part, data in PART_DATA.items():
            img_path = os.path.join(base_dir, "assets", data['img'])
            try:
                loaded_img = pygame.image.load(img_path).convert_alpha()
                max_w = max(p[0] for p in SHAPES[part]) + 1
                max_h = max(p[1] for p in SHAPES[part]) + 1
                self.images[part] = pygame.transform.scale(loaded_img, (max_w * GRID_SIZE, max_h * GRID_SIZE))
            except: self.images[part] = None

        self.grid = [[None for _ in range(COLUMNS)] for _ in range(ROWS)]
        self.current_piece = Piece(random.choice(list(SHAPES.keys())))
        self.next_piece = Piece(random.choice(list(SHAPES.keys())))
        self.score, self.level, self.lines_cleared = 0, 1, 0
        self.game_over = False
        self.paused = False

        self.keys_held = {pygame.K_LEFT: False, pygame.K_RIGHT: False, pygame.K_DOWN: False}
        self.move_timer, self.move_delay, self.initial_delay = 0, 70, 180

        # UI Positioning
        cx, cy, s = 100, 650, 55             
        self.btn_u = pygame.Rect(cx, cy - s, s, s)
        self.btn_l = pygame.Rect(cx - s, cy, s, s)
        self.btn_d = pygame.Rect(cx, cy, s, s)
        self.btn_r = pygame.Rect(cx + s, cy, s, s)
        self.btn_rot = pygame.Rect(280, 620, 80, 80)
        self.btn_pause = pygame.Rect(360, 10, 80, 35)

    def get_transformed_image(self, piece):
        img = self.images.get(piece.name)
        if not img: return None
        # Rotate entire texture to match physics
        new_img = pygame.transform.rotate(img, -piece.rotation)
        if piece.is_flipped:
            new_img = pygame.transform.flip(new_img, True, False)
        return new_img

    def check_collision(self, dx, dy, shape=None):
        shape = shape or self.current_piece.shape
        for px, py in shape:
            nx, ny = self.current_piece.x + px + dx, self.current_piece.y + py + dy
            if nx < 0 or nx >= COLUMNS or ny >= ROWS: return True
            if ny >= 0 and self.grid[ny][nx]: return True
        return False

    def try_rotate_with_kick(self, flip=False):
        if flip: new_shape = [(-x, y) for x, y in self.current_piece.shape]
        else: new_shape = [(y, -x) for x, y in self.current_piece.shape]
        for kick in [0, 1, -1, 2, -2]:
            if not self.check_collision(kick, 0, new_shape):
                self.current_piece.x += kick
                self.current_piece.shape = new_shape
                if flip: self.current_piece.is_flipped = not self.current_piece.is_flipped
                else: self.current_piece.rotation = (self.current_piece.rotation + 90) % 360
                return True
        return False

    def freeze_piece(self):
        trans_img = self.get_transformed_image(self.current_piece)
        min_x = min(p[0] for p in self.current_piece.shape)
        min_y = min(p[1] for p in self.current_piece.shape)
        
        for px, py in self.current_piece.shape:
            cell_surface = None
            if trans_img:
                cell_surface = pygame.Surface((GRID_SIZE, GRID_SIZE), pygame.SRCALPHA)
                crop_rect = pygame.Rect((px - min_x) * GRID_SIZE, (py - min_y) * GRID_SIZE, GRID_SIZE, GRID_SIZE)
                cell_surface.blit(trans_img, (0, 0), crop_rect)
            self.grid[self.current_piece.y + py][self.current_piece.x + px] = (self.current_piece.name, cell_surface)
        
        self.clear_lines()
        self.current_piece = self.next_piece
        self.next_piece = Piece(random.choice(list(SHAPES.keys())))
        if self.check_collision(0, 0): self.game_over = True

    def clear_lines(self):
        lines = [i for i, row in enumerate(self.grid) if all(row)]
        if lines:
            self.score += {1: 100, 2: 300, 3: 500, 4: 800}.get(len(lines), 100) * self.level
            self.lines_cleared += len(lines)
            self.level = (self.lines_cleared // 10) + 1
            for i in lines:
                del self.grid[i]
                self.grid.insert(0, [None for _ in range(COLUMNS)])

    def draw_transparent_button(self, rect, text, color=(200, 200, 200)):
        s = pygame.Surface((rect.width, rect.height), pygame.SRCALPHA)
        pygame.draw.rect(s, (*color, 90), (0, 0, rect.width, rect.height), border_radius=8)
        pygame.draw.rect(s, (*color, 200), (0, 0, rect.width, rect.height), 2, border_radius=8)
        self.screen.blit(s, (rect.x, rect.y))
        f = pygame.font.SysFont('Arial', 14, bold=True)
        txt = f.render(text, True, WHITE)
        self.screen.blit(txt, (rect.centerx - txt.get_width()//2, rect.centery - txt.get_height()//2))

    def draw(self):
        self.screen.fill(BLACK)
        pygame.draw.rect(self.screen, GRAY, (0, 0, COLUMNS * GRID_SIZE, ROWS * GRID_SIZE), 1)

        # 1. Grid
        for y, row in enumerate(self.grid):
            for x, cell in enumerate(row):
                if cell:
                    name, slice_img = cell
                    if slice_img: self.screen.blit(slice_img, (x*GRID_SIZE, y*GRID_SIZE))
                    else: pygame.draw.rect(self.screen, PART_DATA[name]['color'], (x*GRID_SIZE, y*GRID_SIZE, GRID_SIZE-1, GRID_SIZE-1))
        
        # 2. Falling Piece (Pinned Texture Logic)
        trans_img = self.get_transformed_image(self.current_piece)
        if trans_img:
            min_x = min(p[0] for p in self.current_piece.shape)
            min_y = min(p[1] for p in self.current_piece.shape)
            for px, py in self.current_piece.shape:
                x_pos, y_pos = (self.current_piece.x + px)*GRID_SIZE, (self.current_piece.y + py)*GRID_SIZE
                crop_rect = pygame.Rect((px - min_x) * GRID_SIZE, (py - min_y) * GRID_SIZE, GRID_SIZE, GRID_SIZE)
                self.screen.blit(trans_img, (x_pos, y_pos), crop_rect)
        else:
            for px, py in self.current_piece.shape:
                pygame.draw.rect(self.screen, self.current_piece.color, ((self.current_piece.x+px)*GRID_SIZE, (self.current_piece.y+py)*GRID_SIZE, GRID_SIZE-1, GRID_SIZE-1))

        # 3. Sidebar UI
        ux = 315
        fm, fs = pygame.font.SysFont('Arial', 18, bold=True), pygame.font.SysFont('Arial', 14)
        self.screen.blit(fm.render(f"LVL: {self.level}", True, WHITE), (ux, 20))
        self.screen.blit(fm.render(f"SCORE: {self.score}", True, WHITE), (ux, 50))
        self.screen.blit(fm.render("NEXT:", True, WHITE), (ux, 90))
        for px, py in self.next_piece.shape:
            pygame.draw.rect(self.screen, self.next_piece.color, (ux + px*15, 120 + py*15, 12, 12))
        
        self.screen.blit(fm.render("PART:", True, WHITE), (ux, 190))
        self.screen.blit(fs.render(self.current_piece.name, True, self.current_piece.color), (ux, 215))
        
        words, line, y_off = self.current_piece.desc.split(), "", 235
        for word in words:
            if fs.size(line + word)[0] < 125: line += word + " "
            else:
                self.screen.blit(fs.render(line, True, WHITE), (ux, y_off))
                line, y_off = word + " ", y_off + 15
        self.screen.blit(fs.render(line, True, WHITE), (ux, y_off))

        # 4. Buttons
        if IS_MOBILE:
            for b, t in [(self.btn_l, "L"), (self.btn_r, "R"), (self.btn_u, "FLIP"), (self.btn_d, "D")]:
                self.draw_transparent_button(b, t)
            self.draw_transparent_button(self.btn_rot, "ROTATE", (100, 255, 100))
        self.draw_transparent_button(self.btn_pause, "PAUSE" if not self.paused else "RESUME", (255, 100, 100))

        if self.paused:
            overlay = pygame.Surface((SCREEN_WIDTH, SCREEN_HEIGHT), pygame.SRCALPHA)
            overlay.fill((0, 0, 0, 180)); self.screen.blit(overlay, (0,0))
            txt = fm.render("PAUSED", True, WHITE)
            self.screen.blit(txt, (SCREEN_WIDTH//2 - txt.get_width()//2, SCREEN_HEIGHT//2))
        pygame.display.flip()

    async def run(self):
        fall_time = 0
        while not self.game_over:
            dt = self.clock.tick(60)
            for event in pygame.event.get():
                if event.type == pygame.QUIT: return
                if event.type == pygame.KEYDOWN and event.key == pygame.K_p: self.paused = not self.paused
                if event.type == pygame.MOUSEBUTTONDOWN:
                    pos = event.pos
                    if self.btn_pause.collidepoint(pos): self.paused = not self.paused
                    if not self.paused and (IS_MOBILE or event.button == 1):
                        if self.btn_l.collidepoint(pos): 
                            self.keys_held[pygame.K_LEFT] = True
                            if not self.check_collision(-1, 0): self.current_piece.x -= 1
                            self.move_timer = -self.initial_delay
                        if self.btn_r.collidepoint(pos): 
                            self.keys_held[pygame.K_RIGHT] = True
                            if not self.check_collision(1, 0): self.current_piece.x += 1
                            self.move_timer = -self.initial_delay
                        if self.btn_d.collidepoint(pos): self.keys_held[pygame.K_DOWN] = True
                        if self.btn_u.collidepoint(pos): self.try_rotate_with_kick(True)
                        if self.btn_rot.collidepoint(pos): self.try_rotate_with_kick(False)
                if event.type == pygame.MOUSEBUTTONUP:
                    for k in [pygame.K_LEFT, pygame.K_RIGHT, pygame.K_DOWN]: self.keys_held[k] = False
                if not self.paused and event.type == pygame.KEYDOWN:
                    if event.key in self.keys_held: 
                        self.keys_held[event.key] = True
                        if event.key == pygame.K_LEFT and not self.check_collision(-1, 0): self.current_piece.x -= 1
                        if event.key == pygame.K_RIGHT and not self.check_collision(1, 0): self.current_piece.x += 1
                        self.move_timer = -self.initial_delay
                    if event.key == pygame.K_SPACE: self.try_rotate_with_kick(False)
                    if event.key == pygame.K_UP: self.try_rotate_with_kick(True)
                    if event.key == pygame.K_RETURN:
                        while not self.check_collision(0, 1): self.current_piece.y += 1
                        self.freeze_piece()
                if event.type == pygame.KEYUP and event.key in self.keys_held: self.keys_held[event.key] = False

            if not self.paused:
                fall_time += dt
                self.move_timer += dt
                spd = max(100, 500 - (self.level - 1) * 50)
                f_spd = spd / 10 if self.keys_held[pygame.K_DOWN] else spd
                if self.move_timer > self.move_delay:
                    if self.keys_held[pygame.K_LEFT] and not self.check_collision(-1, 0): self.current_piece.x -= 1
                    if self.keys_held[pygame.K_RIGHT] and not self.check_collision(1, 0): self.current_piece.x += 1
                    self.move_timer = 0
                if fall_time > f_spd:
                    if not self.check_collision(0, 1): self.current_piece.y += 1
                    else: self.freeze_piece()
                    fall_time = 0
            self.draw()
            await asyncio.sleep(0)

if __name__ == "__main__":
    asyncio.run(AutomotiveTetris().run())