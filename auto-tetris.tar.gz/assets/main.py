import pygame
import random
import asyncio
import os
import sys
import json
import urllib.request

# --- GLOBAL CONFIGURATION ---
SCREEN_WIDTH, SCREEN_HEIGHT = 450, 750 
GRID_SIZE = 30
COLUMNS, ROWS = 10, 20
BLACK = (15, 15, 18)
WHITE = (240, 240, 240)
GRAY = (40, 40, 40)
GOLD = (255, 215, 0)
IS_MOBILE = sys.platform == "emscripten" 

BLUE = (0, 120, 255)
GREEN = (50, 220, 50)
YELLOW = (255, 220, 0)
RED = (255, 50, 50)

# Embedded live project URL address node endpoint
FIREBASE_URL = "https://stack-the-shop-default-rtdb.firebaseio.com/"

PART_DATA = {
    'Spark Plug': {'color': RED, 'imgs': ['sparkplug_0.png', 'sparkplug_90.png', 'sparkplug_180.png', 'sparkplug_270.png'], 'desc': 'Ignites fuel/air mix.'},
    'Ignition Coil': {'color': GREEN, 'imgs': ['coil_0.png', 'coil_90.png', 'coil_180.png', 'coil_270.png'], 'desc': 'Transforms battery voltage.'},
    'Alternator': {'color': BLUE, 'imgs': ['alternator_0.png', 'alternator_0.png', 'alternator_0.png', 'alternator_0.png'], 'desc': 'Charges electrical system.'},
    'VVT Solenoid': {'color': WHITE, 'imgs': ['vvt_0.png', 'vvt_90.png', 'vvt_180.png', 'vvt_270.png'], 'desc': 'Controls valve timing.'},
    'O2 Sensor': {'color': YELLOW, 'imgs': ['o2_0.png', 'o2_90.png', 'o2_180.png', 'o2_270.png'], 'desc': 'Measures exhaust oxygen.'}
}

SHAPES = {
    'Spark Plug': [(0, 0), (1, 0), (2, 0), (3, 0)],    
    'Ignition Coil': [(0, 0), (0, 1), (0, 2), (1, 2)], 
    'Alternator': [(0, 0), (1, 0), (0, 1), (1, 1)],    
    'VVT Solenoid': [(0, 1), (1, 1), (2, 1), (1, 0)],  
    'O2 Sensor': [(0, 1), (1, 0), (1, 1), (2, 0)]      
}

class Piece:
    def __init__(self, name):
        self.shape = list(SHAPES[name])
        self.color = PART_DATA[name]['color']
        self.desc = PART_DATA[name]['desc']
        self.name = name
        self.x = COLUMNS // 2 - 1
        self.y = 0
        self.is_flipped = False
        self.rot_idx = 0 

class AutomotiveTetris:
    def __init__(self):
        pygame.init()
        self.screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
        self.clock = pygame.time.Clock()
        
        self.rotation_images = {} 
        base_dir = os.path.dirname(os.path.abspath(__file__))
        for part, data in PART_DATA.items():
            self.rotation_images[part] = []
            for img_filename in data['imgs']:
                img_path = os.path.join(base_dir, "assets", img_filename)
                try:
                    self.rotation_images[part].append(pygame.image.load(img_path).convert_alpha())
                except:
                    self.rotation_images[part].append(None)

        self.grid = [[None for _ in range(COLUMNS)] for _ in range(ROWS)]
        self.current_piece = Piece(random.choice(list(SHAPES.keys())))
        self.next_piece = Piece(random.choice(list(SHAPES.keys())))
        self.score, self.level, self.lines_cleared = 0, 1, 0
        self.game_over, self.paused = False, False

        # --- FORM STATE ENGINE MECHANICS ---
        self.leaderboard = []
        self.player_initials = ""
        self.form_stage = "INITIALS" 
        self.active_field = 0       
        self.fall_time = 0
        
        self.form_data = {
            "First Name": "", "Last Name": "", "Email": "",
            "Street Address": "", "City": "", "State": "", "Zip Code": ""
        }
        self.form_keys = list(self.form_data.keys())
        
        self.cursor_visible = True
        self.cursor_timer = 0
        self.scroll_y = 0 
        
        self.leaderboard = self.load_leaderboard()

        self.keys_held = {pygame.K_LEFT: False, pygame.K_RIGHT: False, pygame.K_DOWN: False}
        self.move_timer, self.move_delay = 0, 70

        cx, cy, s = 100, 650, 55             
        self.btn_u = pygame.Rect(cx, cy - s, s, s)   
        self.btn_l = pygame.Rect(cx - s, cy, s, s)   
        self.btn_d = pygame.Rect(cx, cy, s, s)       
        self.btn_r = pygame.Rect(cx + s, cy, s, s)   
        self.btn_rot = pygame.Rect(280, 620, 80, 80) 
        self.btn_pause = pygame.Rect(325, 380, 100, 35)
        
        # Interactive UI Form Collision Boundaries
        self.btn_yes = pygame.Rect(60, 180, 140, 45)
        self.btn_no = pygame.Rect(250, 180, 140, 45)
        self.btn_submit_form = pygame.Rect(60, 435, 330, 45)
        
        # Clickable geometry nodes mapping out form fields on screen simultaneously
        self.field_rects = []
        for i in range(7):
            self.field_rects.append(pygame.Rect(160, 160 + (i * 38), 230, 30))

    def load_leaderboard(self):
        url = f"{FIREBASE_URL}scores.json?orderBy=\"score\"&limitToLast=100"
        try:
            req = urllib.request.Request(url, method="GET")
            with urllib.request.urlopen(req, timeout=3) as r:
                raw = json.loads(r.read().decode("utf-8"))
            if not raw: return self.get_baseline_scores()
            return sorted(list(raw.values()), key=lambda x: x["score"], reverse=True)
        except:
            return self.get_baseline_scores()

    def submit_high_score(self, wants_prize=False):
        url = f"{FIREBASE_URL}scores.json"
        try:
            payload = {
                "name": self.player_initials.upper().strip(),
                "score": self.score,
                "level": self.level,
                "prize_entrant": wants_prize
            }
            if wants_prize:
                payload.update({k.lower().replace(" ", "_"): v.strip() for k, v in self.form_data.items()})
                
            json_bytes = json.dumps(payload).encode("utf-8")
            req = urllib.request.Request(url, data=json_bytes, method="POST")
            req.add_header("Content-Type", "application/json")
            with urllib.request.urlopen(req, timeout=3) as response: pass
            
            self.form_stage = "SUBMITTED"
            self.leaderboard = self.load_leaderboard()
        except Exception as e:
            print("Failed submission sync:", e)
            self.form_stage = "SUBMITTED"

    def get_baseline_scores(self):
        return [{"name": "CPU", "score": 10000 - (i * 100), "level": 1} for i in range(100)]

    def reset_game_state(self):
        """Wipes and zeroes all time tracking properties to eliminate speed bugs"""
        self.grid = [[None for _ in range(COLUMNS)] for _ in range(ROWS)]
        self.current_piece = Piece(random.choice(list(SHAPES.keys())))
        self.next_piece = Piece(random.choice(list(SHAPES.keys())))
        self.score, self.level, self.lines_cleared = 0, 1, 0
        self.game_over = False
        self.player_initials = ""
        self.form_stage = "INITIALS"
        self.active_field = 0
        for k in self.form_data: self.form_data[k] = ""
        self.scroll_y = 0
        self.move_timer = 0
        self.fall_time = 0
        
        # Force keys_held back to false on transition
        for k in self.keys_held:
            self.keys_held[k] = False

    def get_piece_surface(self, piece):
        img_list = self.rotation_images.get(piece.name)
        if not img_list or not img_list[piece.rot_idx]: return None
        raw_surf = img_list[piece.rot_idx]
        target_w = (max(p[0] for p in piece.shape) + 1) * GRID_SIZE
        target_h = (max(p[1] for p in piece.shape) + 1) * GRID_SIZE
        surf = pygame.transform.scale(raw_surf, (target_w, target_h))
        if piece.is_flipped: surf = pygame.transform.flip(surf, True, False)
        return surf

    def check_collision(self, dx, dy, shape=None):
        shape = shape or self.current_piece.shape
        for px, py in shape:
            nx, ny = self.current_piece.x + px + dx, self.current_piece.y + py + dy
            if nx < 0 or nx >= COLUMNS or ny >= ROWS: return True
            if ny >= 0 and self.grid[ny][nx]: return True
        return False

    def try_rotate_with_kick(self, flip=False):
        if flip: new_shape = [(-x, y) for x, y in self.current_piece.shape]
        else: new_shape = [(y, -x) for x, y in self.current_piece.shape]
        mx, my = min(p[0] for p in new_shape), min(p[1] for p in new_shape)
        norm_shape = [(p[0] - mx, p[1] - my) for p in new_shape]
        for kick in [0, 1, -1, 2, -2]:
            if not self.check_collision(kick, 0, norm_shape):
                self.current_piece.x += kick
                self.current_piece.shape = norm_shape
                if flip: self.current_piece.is_flipped = not self.current_piece.is_flipped
                else: self.current_piece.rot_idx = (self.current_piece.rot_idx + 1) % 4
                return True
        return False

    def freeze_piece(self):
        surf = self.get_piece_surface(self.current_piece)
        for px, py in self.current_piece.shape:
            slice_img = None
            if surf:
                slice_img = pygame.Surface((GRID_SIZE, GRID_SIZE), pygame.SRCALPHA)
                slice_img.blit(surf, (0, 0), (px * GRID_SIZE, py * GRID_SIZE, GRID_SIZE, GRID_SIZE))
            self.grid[self.current_piece.y + py][self.current_piece.x + px] = (self.current_piece.name, slice_img)
        self.clear_lines()
        self.current_piece = self.next_piece
        self.next_piece = Piece(random.choice(list(SHAPES.keys())))
        if self.check_collision(0, 0): self.game_over = True

    def clear_lines(self):
        lines = [i for i, row in enumerate(self.grid) if all(row)]
        if lines:
            self.score += {1: 100, 2: 300, 3: 500, 4: 800}.get(len(lines), 100) * self.level
            self.lines_cleared += len(lines)
            self.level = (self.lines_cleared // 10) + 1
            for i in lines:
                del self.grid[i]
                self.grid.insert(0, [None for _ in range(COLUMNS)])

    def draw_transparent_button(self, rect, text, color=(200, 200, 200)):
        s = pygame.Surface((rect.width, rect.height), pygame.SRCALPHA)
        pygame.draw.rect(s, (*color, 90), (0, 0, rect.width, rect.height), border_radius=8)
        pygame.draw.rect(s, (*color, 200), (0, 0, rect.width, rect.height), 2, border_radius=8)
        self.screen.blit(s, (rect.x, rect.y))
        f = pygame.font.SysFont('Arial', 16, bold=True)
        txt = f.render(text, True, WHITE)
        self.screen.blit(txt, (rect.centerx - txt.get_width()//2, rect.centery - txt.get_height()//2))

    def draw_game_over_screen(self, fm, fs):
        overlay = pygame.Surface((SCREEN_WIDTH, SCREEN_HEIGHT), pygame.SRCALPHA)
        overlay.fill((12, 12, 16, 252)) 
        self.screen.blit(overlay, (0,0))
        
        t1 = fm.render("GAME OVER", True, RED)
        t2 = fs.render(f"Final Score: {self.score}   |   Level: {self.level}", True, WHITE)
        self.screen.blit(t1, (SCREEN_WIDTH // 2 - t1.get_width() // 2, 15))
        self.screen.blit(t2, (SCREEN_WIDTH // 2 - t2.get_width() // 2, 42))
        
        y_section = 80
        
        # --- STAGE 1: ENTER INITIALS ---
        if self.form_stage == "INITIALS":
            prompt = fm.render("ENTER YOUR INITIALS:", True, GOLD)
            self.screen.blit(prompt, (SCREEN_WIDTH // 2 - prompt.get_width() // 2, y_section))
            display_i = (self.player_initials + "___")[:3]
            spaced_i = "  ".join(list(display_i))
            surf_i = fm.render(spaced_i, True, WHITE)
            self.screen.blit(surf_i, (SCREEN_WIDTH // 2 - surf_i.get_width() // 2, y_section + 30))
            if self.cursor_visible and len(self.player_initials) < 3:
                cx = (SCREEN_WIDTH // 2 - surf_i.get_width() // 2) + (len(self.player_initials) * 28) + 4
                pygame.draw.line(self.screen, GOLD, (cx, y_section + 30), (cx, y_section + 55), 3)
            y_section += 100

        # --- STAGE 2: PRIZE OPT-IN QUESTION ---
        elif self.form_stage == "OPT_IN":
            q1 = fm.render("WOULD YOU LIKE TO BE ENTERED", True, GOLD)
            q2 = fm.render("TO WIN A PRIZE?", True, GOLD)
            self.screen.blit(q1, (SCREEN_WIDTH // 2 - q1.get_width() // 2, y_section))
            self.screen.blit(q2, (SCREEN_WIDTH // 2 - q2.get_width() // 2, y_section + 25))
            
            self.draw_transparent_button(self.btn_yes, "YES, ENTER ME!", (50, 200, 50))
            self.draw_transparent_button(self.btn_no, "NO THANKS", (200, 50, 50))
            y_section += 170

        # --- STAGE 3: ALL FIELDS ON SCREEN AT ONCE ---
        elif self.form_stage == "FORM_FIELDS":
            title = fm.render("PRIZE SHIPPING REGISTRATION", True, BLUE)
            self.screen.blit(title, (SCREEN_WIDTH // 2 - title.get_width() // 2, y_section))
            
            for idx, key in enumerate(self.form_keys):
                rect = self.field_rects[idx]
                is_active = (idx == self.active_field)
                
                border_color = BLUE if is_active else GRAY
                pygame.draw.rect(self.screen, border_color, rect, 1, border_radius=4)
                
                lbl_surf = fs.render(f"{key}:", True, GOLD if is_active else WHITE)
                self.screen.blit(lbl_surf, (45, rect.y + 6))
                
                val_surf = fs.render(self.form_data[key], True, WHITE)
                self.screen.blit(val_surf, (rect.x + 8, rect.y + 6))
                
                if is_active and self.cursor_visible:
                    cx = rect.x + 8 + val_surf.get_width() + 2
                    pygame.draw.line(self.screen, WHITE, (cx, rect.y + 6), (cx, rect.y + 22), 2)
            
            self.draw_transparent_button(self.btn_submit_form, "SUBMIT REGISTRATION", (50, 200, 50))
            y_section = 490

        elif self.form_stage == "SUBMITTED":
            saved = fm.render("SCORE & PRIZE ENTRY RECORDED!", True, GREEN)
            self.screen.blit(saved, (SCREEN_WIDTH // 2 - saved.get_width() // 2, y_section + 10))
            y_section += 60

        # --- DYNAMIC PLAYER RANK CALCULATION ---
        player_rank_str = "HONORABLE MENTION"
        for idx, entry in enumerate(self.leaderboard):
            if self.score >= entry['score']:
                player_rank_str = f"#{idx + 1} GLOBAL"
                break
        
        rank_lbl = fs.render("YOUR PLACEMENT:", True, WHITE)
        rank_val = fm.render(player_rank_str, True, GOLD)
        self.screen.blit(rank_lbl, (65, y_section))
        self.screen.blit(rank_val, (215, y_section - 2))
        y_section += 24

        # --- GLOBAL LEADERBOARD SCROLL PANEL ---
        lbl = fm.render("GLOBAL LEADERBOARD (TOP 100)", True, BLUE)
        self.screen.blit(lbl, (SCREEN_WIDTH // 2 - lbl.get_width() // 2, y_section))
        
        scroll_rect = pygame.Rect(40, y_section + 22, SCREEN_WIDTH - 80, 150)
        pygame.draw.rect(self.screen, GRAY, scroll_rect, 1)
        
        list_surf = pygame.Surface((scroll_rect.width - 10, 100 * 30), pygame.SRCALPHA)
        for idx, entry in enumerate(self.leaderboard):
            item_y = idx * 30
            if item_y + 30 < self.scroll_y or item_y > self.scroll_y + scroll_rect.height: continue
            
            is_p = (entry['score'] == self.score and entry['name'] == self.player_initials)
            tint = GOLD if is_p else (WHITE if idx > 2 else BLUE)
            
            list_surf.blit(fs.render(f"{idx + 1}.", True, GRAY), (10, item_y))
            list_surf.blit(fs.render(f"{entry['name'].upper()}", True, tint), (50, item_y))
            list_surf.blit(fs.render(f"{entry['score']:,} pts", True, WHITE), (140, item_y))
            list_surf.blit(fs.render(f"Lvl {entry['level']}", True, GRAY), (260, item_y))
            
        self.screen.blit(list_surf, (scroll_rect.x, scroll_rect.y), (0, self.scroll_y, scroll_rect.width, scroll_rect.height))
        
        hint = fs.render("Press 'ENTER' Key or Click Outside Forms to Play Again", True, WHITE)
        self.screen.blit(hint, (SCREEN_WIDTH // 2 - hint.get_width() // 2, scroll_rect.bottom + 10))

    def draw(self):
        self.screen.fill(BLACK)
        pygame.draw.rect(self.screen, GRAY, (0, 0, COLUMNS * GRID_SIZE, ROWS * GRID_SIZE), 1)

        # 1. Grid
        for y, row in enumerate(self.grid):
            for x, cell in enumerate(row):
                if cell: self.screen.blit(cell[1], (x*GRID_SIZE, y*GRID_SIZE))
        
        # 2. Active falling asset
        surf = self.get_piece_surface(self.current_piece)
        if surf: self.screen.blit(surf, (self.current_piece.x * GRID_SIZE, self.current_piece.y * GRID_SIZE))

        # 3. Sidebar Panel
        ux, fm, fs = 315, pygame.font.SysFont('Arial', 18, bold=True), pygame.font.SysFont('Arial', 14)
        self.screen.blit(fm.render(f"LVL: {self.level}", True, WHITE), (ux, 20))
        self.screen.blit(fm.render(f"SCORE: {self.score}", True, WHITE), (ux, 50))
        self.screen.blit(fm.render("NEXT:", True, WHITE), (ux, 90))
        for px, py in self.next_piece.shape:
            pygame.draw.rect(self.screen, self.next_piece.color, (ux + px*15, 120 + py*15, 12, 12))
        
        self.screen.blit(fm.render("PART:", True, WHITE), (ux, 190))
        self.screen.blit(fs.render(self.current_piece.name, True, self.current_piece.color), (ux, 215))
        
        words, line, y_off = self.current_piece.desc.split(), "", 235
        for word in words:
            if fs.size(line + word)[0] < 125: line += word + " "
            else:
                self.screen.blit(fs.render(line, True, WHITE), (ux, y_off))
                line, y_off = word + " ", y_off + 15
        self.screen.blit(fs.render(line, True, WHITE), (ux, y_off))

        if IS_MOBILE:
            self.draw_transparent_button(self.btn_l, "←")
            self.draw_transparent_button(self.btn_r, "→")
            self.draw_transparent_button(self.btn_d, "↓")
            self.draw_transparent_button(self.btn_u, "FLIP")
            self.draw_transparent_button(self.btn_rot, "ROTATE", (100, 255, 100))
        
        self.draw_transparent_button(self.btn_pause, "PAUSE" if not self.paused else "RESUME", (255, 100, 100))
        if self.paused:
            overlay = pygame.Surface((SCREEN_WIDTH, SCREEN_HEIGHT), pygame.SRCALPHA)
            overlay.fill((0, 0, 0, 180)); self.screen.blit(overlay, (0,0))
            txt = fm.render("PAUSED", True, WHITE)
            self.screen.blit(txt, (SCREEN_WIDTH//2 - txt.get_width()//2, SCREEN_HEIGHT//2))
            
        if self.game_over: self.draw_game_over_screen(fm, fs)
        pygame.display.flip()

    async def run(self):
        self.fall_time = 0
        while True:
            dt = self.clock.tick(60)
            if self.game_over:
                self.cursor_timer += dt
                if self.cursor_timer >= 400:
                    self.cursor_visible, self.cursor_timer = not self.cursor_visible, 0
            
            for event in pygame.event.get():
                if event.type == pygame.QUIT: return
                
                # --- INTERACTIVE FORMS GAME OVER MANAGER ---
                if self.game_over:
                    if event.type == pygame.MOUSEBUTTONDOWN:
                        if event.button == 4: self.scroll_y = max(0, self.scroll_y - 25)
                        elif event.button == 5: self.scroll_y = max(0, min(self.scroll_y + 25, 2850))
                        else:
                            if self.form_stage == "OPT_IN":
                                if self.btn_yes.collidepoint(event.pos): self.form_stage = "FORM_FIELDS"
                                elif self.btn_no.collidepoint(event.pos): self.submit_high_score(False)
                            elif self.form_stage == "FORM_FIELDS":
                                for idx, rect in enumerate(self.field_rects):
                                    if rect.collidepoint(event.pos): self.active_field = idx
                                if self.btn_submit_form.collidepoint(event.pos):
                                    self.submit_high_score(True)
                            elif self.form_stage == "SUBMITTED":
                                pygame.event.clear()
                                self.reset_game_state()
                                
                    elif event.type == pygame.KEYDOWN:
                        if event.key == pygame.K_UP: self.scroll_y = max(0, self.scroll_y - 20)
                        elif event.key == pygame.K_DOWN: self.scroll_y = max(0, min(self.scroll_y + 20, 2850))
                        
                        elif self.form_stage == "INITIALS":
                            if event.key == pygame.K_RETURN and len(self.player_initials) > 0: self.form_stage = "OPT_IN"
                            elif event.key == pygame.K_BACKSPACE: self.player_initials = self.player_initials[:-1]
                            elif len(self.player_initials) < 3 and event.unicode.isalpha(): self.player_initials += event.unicode.upper()
                            
                        elif self.form_stage == "FORM_FIELDS":
                            f_key = self.form_keys[self.active_field]
                            if event.key == pygame.K_RETURN or event.key == pygame.K_TAB:
                                if self.active_field < 6: self.active_field += 1
                                else: self.submit_high_score(True)
                            elif event.key == pygame.K_BACKSPACE: self.form_data[f_key] = self.form_data[f_key][:-1]
                            elif event.unicode.isprintable(): self.form_data[f_key] += event.unicode
                            
                        elif self.form_stage == "SUBMITTED" and event.key == pygame.K_RETURN:
                            pygame.event.clear()
                            self.reset_game_state()
                    continue
                
                if event.type == pygame.KEYDOWN and event.key == pygame.K_p: self.paused = not self.paused
                if event.type == pygame.MOUSEBUTTONDOWN:
                    if self.btn_pause.collidepoint(event.pos): self.paused = not self.paused
                    if not self.paused and (IS_MOBILE or event.button == 1):
                        if self.btn_l.collidepoint(event.pos): self.keys_held[pygame.K_LEFT] = True
                        if self.btn_r.collidepoint(event.pos): self.keys_held[pygame.K_RIGHT] = True
                        if self.btn_d.collidepoint(event.pos): self.keys_held[pygame.K_DOWN] = True
                        if self.btn_u.collidepoint(event.pos): self.try_rotate_with_kick(True)
                        if self.btn_rot.collidepoint(event.pos): self.try_rotate_with_kick(False)
                if event.type == pygame.MOUSEBUTTONUP:
                    for k in [pygame.K_LEFT, pygame.K_RIGHT, pygame.K_DOWN]: self.keys_held[k] = False
                if not self.paused and event.type == pygame.KEYDOWN:
                    if event.key in self.keys_held: self.keys_held[event.key] = True
                    if event.key == pygame.K_LEFT and not self.check_collision(-1, 0): self.current_piece.x -= 1
                    if event.key == pygame.K_RIGHT and not self.check_collision(1, 0): self.current_piece.x += 1
                    if event.key == pygame.K_SPACE: self.try_rotate_with_kick(False)
                    if event.key == pygame.K_UP: self.try_rotate_with_kick(True)
                    if event.key == pygame.K_RETURN:
                        while not self.check_collision(0, 1): self.current_piece.y += 1
                        self.freeze_piece()
                if event.type == pygame.KEYUP and event.key in self.keys_held: self.keys_held[event.key] = False

            if not self.paused and not self.game_over:
                self.fall_time += dt
                self.move_timer += dt
                spd = max(80, 350 - (self.level - 1) * 45)
                f_spd = spd / 10 if self.keys_held[pygame.K_DOWN] else spd
                if self.move_timer > self.move_delay:
                    if self.keys_held[pygame.K_LEFT] and not self.check_collision(-1, 0): self.current_piece.x -= 1
                    if self.keys_held[pygame.K_RIGHT] and not self.check_collision(1, 0): self.current_piece.x += 1
                    self.move_timer = 0
                if self.fall_time > f_spd:
                    if not self.check_collision(0, 1): self.current_piece.y += 1
                    else: self.freeze_piece()
                    self.fall_time = 0
            self.draw()
            await asyncio.sleep(0)

if __name__ == "__main__":
    asyncio.run(AutomotiveTetris().run())